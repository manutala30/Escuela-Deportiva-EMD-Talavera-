<?php
/*Conexion con cualquier BBDD*/
define('servidor','localhost');
define('usuario','emdtalavera1');
define('password','12345');
define('basedatos','escueladeportiva');
?>